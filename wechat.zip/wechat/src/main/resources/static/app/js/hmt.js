// JavaScript Document
$(function(){


    /**
	 * 把这个网页授权的js部分写在htm.js里，需要用到的页面就引用这个js文件，从而得到网页授权相关的js，这样
	 * 就不用在每个需要用到网页授权的网页都写这一段网页授权js代码（需要网页授权的网页不要忘了引入这个htm.js文件哟！）
	 * 注意：这个js文件要先于分享的js执行不然就取不到放在session里的wxUser了
     * @type {string}
     */
    var url=location.href;//获取微信服务器传过来的url（因为里面包含要用到的code）
    var code=url.split("&")[0].split("=")[1];//把code的值分离出来

    getUserInfo();//就算是打开网页就加载但函数必须要调用一下才会执行

    function getUserInfo() {

        $.ajax({

            type:"post",
            url:"http://0gymwv8.hn3.mofasuidao.cn/wechat/oauth",
            data:{"code":code},
			//如果这里不弄成同步的话，有可能会出现ajax还没执行完先把引用这个文件下面的其他引用文件执行了，而我们应该先执行这个js获取wxUser后再执行其他需要wxUser的js
            async:false,//默认为true异步传输（执行到success前先跳过success先执行下面的代码，等后端把响应的结果传回给success后再执行success里面的代码），当为false时表示ajax为同步传输(同步会依次往下执行，要先把success里面的执行完了再执行下面的代码)
            dataType:"json",
            success:function (cs) {

                //将后端传过来的openid设置到浏览器硬盘中
                localStorage.setItem("openid",cs.data);
            }

        });

    }







    //计算内容上下padding
	reContPadding({main:"#main",header:"#header",footer:"#footer"});
	function reContPadding(o){
		var main = o.main || "#main",
			header = o.header || null,
			footer = o.footer || null;
		var cont_pt = $(header).outerHeight(true),
			cont_pb = $(footer).outerHeight(true);
		$(main).css({paddingTop:cont_pt,paddingBottom:cont_pb});
	}

});





//折叠展开列表内容
$(document).ready(function(){
  mui('#slider').on('tap', '.open-btn', function (e) {
	  $(".nav-con").fadeToggle("fast");
	  $(".open-btn span").toggleClass('rotate'); 	
	  if($(".open-btn span").hasClass('rotate')){
		 $("#slider").on("touchmove.ddd",function(e){
			// console.log(e)
			  e.stopPropagation();
		});
	  }else{
		  console.log(1)
		 $("#slider").off("touchmove.ddd");  
	  }
  });
});