package com.example.wechat.common;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class ChangeUrlToOauthUrl {


    /**
     * 把以前的链接变成网页授权形式的url
     * @param url
     * @return
     */
    public static String changeUrl(String url){

        try {
            //把要以前的链接地址进行处理，用 urlEncode 对链接进行处理
            String encodeUrl = URLEncoder.encode(url, "utf-8");

            //把新拼接的需要传给微信服务器的链接赋值给url变量
            url="https://open.weixin.qq.com/connect/oauth2/authorize?appid="+Constant.APPID+"&redirect_uri="+encodeUrl+"&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect\n";


        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        return url;
    }



}
