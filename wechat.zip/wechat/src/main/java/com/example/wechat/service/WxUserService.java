package com.example.wechat.service;

import com.example.wechat.common.JsonBean;
import com.example.wechat.domain.model.WxUser;

public interface WxUserService {

    JsonBean selectByPrimaryKey(Integer id);

    JsonBean insert(WxUser wxUser);

    WxUser selectByOpenId(String openId);
    int updateSubscribe(WxUser record);

    JsonBean selectByfId(String fId);


}
