package com.example.wechat.common;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

import java.io.IOException;

public class HttpClientUtil {


    public static JSONObject doGet(String url) throws IOException {

        JSONObject jsonObject = null;
        HttpGet httpGet = new HttpGet(url);
        HttpClient httpClient = new DefaultHttpClient();

        HttpResponse httpResponse = httpClient.execute(httpGet);
        if (httpResponse.getStatusLine().getStatusCode() == 200) {
            String s = EntityUtils.toString(httpResponse.getEntity(), "utf-8");
            jsonObject = new JSONObject(s);

        }

        return jsonObject;
    }



    public  static JSONObject doPost(String url,String str) throws IOException {
        JSONObject jsonObject=null;
        HttpPost httpPost = new HttpPost(url);
        HttpClient httpClient = new DefaultHttpClient();

        httpPost.setEntity(new StringEntity(str,"utf-8"));

        HttpResponse httpResponse = httpClient.execute(httpPost);
        if (httpResponse.getStatusLine().getStatusCode()==200){
            String s = EntityUtils.toString(httpResponse.getEntity(), "utf-8");
            jsonObject = new JSONObject(s);
        }

        return jsonObject;
    }



}
