package com.example.wechat.common;

import org.json.JSONObject;

import java.io.IOException;

public class QRCodeTest {
    public static void main(String[] args) {
        String url="https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token="+Constant.getAccessToken();
        //当action_name为QR_STR_SCENE（有STR说明为字符串参数值），后面的场景值ID为字符串类型写成scene_str；如果前面action_name没有STR字母则表明它是整数型的后面则用scene_id
        String str="{\"expire_seconds\": 2592000, \"action_name\": \"QR_STR_SCENE\", \"action_info\": {\"scene\": {\"scene_str\": 2}}}";
        try {
            JSONObject jsonObject = HttpClientUtil.doPost(url, str);
            System.out.println("jsonObject"+jsonObject);
            String ticket=jsonObject.get("ticket").toString();
            System.out.println(ticket);

           //通过ticket换取二维码, HTTP GET请求（请使用https协议）"https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket="+ticket

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
