package com.example.wechat.common;

import org.json.JSONObject;

import java.io.IOException;
import java.security.MessageDigest;
import java.util.*;

public class JsSdkUtil {

    public static Map<String, Object> getJsSdkConfigMap(String targetUrl) {
        Map<String,Object> map=new HashMap<>();

        String appId = Constant.APPID; // 必填，公众号的唯一标识
        long timestamp = System.currentTimeMillis() / 1000; // 必填，生成签名的时间戳
        //通过UUID来生成随机字符串，由于UUID.randomUUID()生成出来的是UUID类型的所以要转为字符串型但转过来后很长而且中间有"-"所以把它去掉然后只取16个字符就行了
        String nonceStr = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 16); // 必填，生成签名的随机串
        String signature = null;// 必填，签名
        // jsApiList: []  必填，需要使用的JS接口列表,我们这里直接把这个交给前端来写，这里不写它

       // 签名用的url必须是调用JS接口页面的完整URL,但不包含#及其后面部分
        String str="jsapi_ticket="+Constant.getJsapiTicket()+"&noncestr="+nonceStr+"&timestamp="+timestamp+"&url="+targetUrl;//自己根据a-z排的字典序，所以就省去了Collections.sort()
        signature=getSha1(str);





        map.put("appId",appId);
        map.put("timestamp",timestamp);
        map.put("nonceStr",nonceStr);//注意这里是一个坑，由于微信平台开发文档不是一个人写的，行了它第二个单词"S"大写了（其他的那些单词全是小写）所以这里传回去的key的名字也要大写
        map.put("signature",signature);



        return map;
    }




    public static String getSha1(String str) {

        char hexDigits[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
                'a', 'b', 'c', 'd', 'e', 'f' };
        try {
            MessageDigest mdTemp = MessageDigest.getInstance("SHA1");
            mdTemp.update(str.getBytes("UTF-8"));
            byte[] md = mdTemp.digest();
            int j = md.length;
            char buf[] = new char[j * 2];
            int k = 0;
            for (int i = 0; i < j; i++) {
                byte byte0 = md[i];
                buf[k++] = hexDigits[byte0 >>> 4 & 0xf];
                buf[k++] = hexDigits[byte0 & 0xf];
            }
            return new String(buf);
        } catch (Exception e) {
            return null;
        }
    }



}
