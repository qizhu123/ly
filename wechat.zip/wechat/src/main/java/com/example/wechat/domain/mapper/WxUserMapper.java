package com.example.wechat.domain.mapper;

import com.example.wechat.domain.model.WxUser;

import java.util.List;

public interface WxUserMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(WxUser record);

    int insertSelective(WxUser record);

    WxUser selectByPrimaryKey(Integer id);
    WxUser selectByOpenId(String openId);

    List<WxUser> selectByfId(String fId);

    int updateByPrimaryKeySelective(WxUser record);
    int updateSubscribe(WxUser record);

    int updateByPrimaryKey(WxUser record);
}