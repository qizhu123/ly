package com.example.wechat.service.impl;

import com.example.wechat.common.JsonBean;
import com.example.wechat.domain.mapper.WxUserMapper;
import com.example.wechat.domain.model.WxUser;
import com.example.wechat.service.WxUserService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class WxUserServiceImpl implements WxUserService {



    // @Autowired
    @Resource
    private WxUserMapper wxUserMapper;

    @Override
    public JsonBean selectByPrimaryKey(Integer id) {

        return new JsonBean(0,"ok",wxUserMapper.selectByPrimaryKey(id));
    }

    @Override
    public JsonBean insert(WxUser wxUser) {
        JsonBean jsonBean = new JsonBean(-1,"失败",null);
        int n = wxUserMapper.insert(wxUser);
        if(n>0){
            jsonBean = new JsonBean(0,"成功",null);
        }


        return jsonBean;
    }

    @Override
    public WxUser selectByOpenId(String openId) {

        WxUser wxUser = wxUserMapper.selectByOpenId(openId);
        return wxUser;
    }

    @Override
    public int updateSubscribe(WxUser record) {
        int i = wxUserMapper.updateSubscribe(record);

        return i;
    }

    @Override
    public JsonBean selectByfId(String fId) {
        JsonBean jsonBean = new JsonBean(-1,"失败",null);

        List<WxUser> wxUsers = wxUserMapper.selectByfId(fId);

        if(wxUsers!=null){
            jsonBean = new JsonBean(0,"成功",wxUsers);
        }


        return jsonBean;
    }
}
