package com.example.wechat;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//在mapper层加@Mapper，是一样的效果,只不过如果有多个mapper时每个mapper类的上面都要加@Mapper注解，用这种方式只需要写一次就行
@MapperScan("com.example.wechat.domain.mapper")
@SpringBootApplication
public class WechatApplication {

    public static void main(String[] args) {
        SpringApplication.run(WechatApplication.class, args);
    }

}
