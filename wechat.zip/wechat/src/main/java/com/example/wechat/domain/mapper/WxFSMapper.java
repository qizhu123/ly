package com.example.wechat.domain.mapper;

import com.example.wechat.domain.model.WxFS;

import java.util.List;

public interface WxFSMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(WxFS record);

    int insertSelective(WxFS record);

    WxFS selectByPrimaryKey(Integer id);



    int updateByPrimaryKeySelective(WxFS record);

    int updateByPrimaryKey(WxFS record);
}