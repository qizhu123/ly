package com.example.wechat.service.impl;

import com.example.wechat.common.*;
import com.example.wechat.domain.mapper.WxFSMapper;
import com.example.wechat.domain.mapper.WxUserMapper;
import com.example.wechat.domain.model.WxFS;
import com.example.wechat.domain.model.WxUser;
import com.example.wechat.service.MessageService;
import org.jdom2.Element;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public class MessageServiceImpl implements MessageService {

    @Autowired
    private WxUserMapper wxUserMapper;

    @Autowired
    private WxFSMapper wxFSMapper;


    @Override
    public String updateMessage(Element rootElement) {

        String toUserName = rootElement.getChildText("ToUserName");//开发者微信号
        String fromUserName = rootElement.getChildText("FromUserName");//发送方帐号（一个OpenID）
        String createTime = rootElement.getChildText("CreateTime");//消息创建时间 （整型）
        String msgType = rootElement.getChildText("MsgType");//消息类型，event
        String event = rootElement.getChildText("Event");//事件类型，subscribe(订阅)、unsubscribe(取消订阅)

        String eventKey = rootElement.getChildText("EventKey");//事件KEY值，qrscene_为前缀，后面为二维码的参数值
        String ticket = rootElement.getChildText("Ticket");//二维码的ticket，可用来换取二维码图片


        String xml = msgType(msgType, event,fromUserName,toUserName,eventKey);


        return xml;
    }




    private  String msgType(String msgType,String event,String openId,String toUserName,String eventKey){

        String xml="Success";

        //进入消息类型
        if(msgType.equals("event")){
            System.out.println("进入事件类型消息");
            //进入事件类型
            if (event.equals("subscribe")){
                System.out.println("进入关注事件");
                xml=sub(openId,toUserName,eventKey);
            }else  if (event.equals("unsubscribe")){
                System.out.println("进入取消关注事件");
                unSub(openId);
            }else  if (event.equals("SCAN")){
                System.out.println("进入已经关注用户扫码SCAN");


            }else  if (event.equals("LOCATION")){
                System.out.println("进入LOCATION");
            }else  if (event.equals("CLICK")){
                System.out.println("进入CLICK");
            }else  if (event.equals("VIEW")){
                System.out.println("进入VIEW");
            }

        }else  if(msgType.equals("text")){
            System.out.println("进入文本消息");
        }else  if(msgType.equals("image")){
            System.out.println("进入图片消息");
        }else  if(msgType.equals("voice")){
            System.out.println("进入语音消息");
        }else  if(msgType.equals("video")){
            System.out.println("进入视频消息");
        }else  if(msgType.equals("shortvideo")){
            System.out.println("进入小视频消息");
        }else  if(msgType.equals("location")){
            System.out.println("进入地理位置消息");
        }else  if(msgType.equals("link")){
            System.out.println("进入链接消息");
        }

        return  xml;
    }



    private String sub(String openId,String toUserName,String eventKey){
        String xml="Success";
        WxUser dbWxUser = wxUserMapper.selectByOpenId(openId);
        if(dbWxUser==null){
            WxUser wxUserInfo = getWxUserInfo(openId);
            wxUserMapper.insert(wxUserInfo);
             System.out.println("添加"+openId+"用户成功：");
            System.out.println("eventKey====>"+eventKey);
            System.out.println("openId====>"+openId);
             if(eventKey!=""&&openId!=""){


                 String fId=eventKey.split("_")[1];
                 System.out.println(fId);
                 WxFS wxFS = new WxFS();
                 wxFS.setFid(fId);
                 wxFS.setSid(openId);
                 int i = wxFSMapper.insert(wxFS);
                 if(i>0){
                     System.out.println("往中间表添加数据成功！");
                 }

             }


        }else{
            if(dbWxUser.getSubscribe()==0){

                dbWxUser.setSubscribe(1);
                int i = wxUserMapper.updateSubscribe(dbWxUser);
                if (i>0){
                    System.out.println("关注成功");
                }
            }
        }

        //完成后进行图文推送,这里由于发送方是我们（开发者向微信用户发送推文），所以这里FromUserName（发送方）是前面的toUserName变量（在前面代表我们开发者），也就是说反过来了
        xml="<xml>\n" +
                "  <ToUserName><![CDATA["+openId+"]]></ToUserName>\n" +
                "  <FromUserName><![CDATA["+toUserName+"]]></FromUserName>\n" +
                "  <CreateTime>"+System.currentTimeMillis()/1000+"</CreateTime>\n" +
                "  <MsgType><![CDATA[news]]></MsgType>\n" +
                "  <ArticleCount>3</ArticleCount>\n" +
                "  <Articles>\n" +

                "    <item>\n" +
                "      <Title><![CDATA[分享送红包]]></Title>\n" +
                "      <Description><![CDATA[分享送红包]]></Description>\n" +
                "      <PicUrl><![CDATA[http://0gymwv8.hn3.mofasuidao.cn/app/images/0928.jpg]]></PicUrl>\n" +
                "      <Url><![CDATA["+ ChangeUrlToOauthUrl.changeUrl("http://0gymwv8.hn3.mofasuidao.cn/app/extension.html")+"]]></Url>\n" +
                "    </item>\n" +

                "    <item>\n" +
                "      <Title><![CDATA[秒杀活动]]></Title>\n" +
                "      <Description><![CDATA[秒杀活动]]></Description>\n" +
                "      <PicUrl><![CDATA[http://0gymwv8.hn3.mofasuidao.cn/app/images/title.png]]></PicUrl>\n" +
                "      <Url><![CDATA["+ ChangeUrlToOauthUrl.changeUrl("http://0gymwv8.hn3.mofasuidao.cn/app/timed-seckill.html")+"]]></Url>\n" +
                "    </item>\n" +

                "    <item>\n" +
                "      <Title><![CDATA[幸运抽奖]]></Title>\n" +
                "      <Description><![CDATA[幸运抽奖]]></Description>\n" +
                "      <PicUrl><![CDATA[http://0gymwv8.hn3.mofasuidao.cn/app/images/middle.png]]></PicUrl>\n" +
                "      <Url><![CDATA["+ ChangeUrlToOauthUrl.changeUrl("http://0gymwv8.hn3.mofasuidao.cn/app/luck-draw.html")+"]]></Url>\n" +
                "    </item>\n" +

                "  </Articles>\n" +
                "</xml>";



        return  xml;
    }

    private  void unSub(String openId){

        /**
         * 表名用户取消了关注，所以把用户的状态修改为未关注状态，但不删除用户数据库中的信息
         */
        System.out.println("进入了取消关注事件，当前用户的openid为："+openId);

        WxUser wxUser = new WxUser();
        wxUser.setOpenid(openId);
        wxUser.setSubscribe(0);
        int i = wxUserMapper.updateSubscribe(wxUser);
        if(i>0){
            System.out.println("取消关注成功！");
        }

    }







    private WxUser getWxUserInfo(String openId){

        WxUser wxUser=null;
        String url="https://api.weixin.qq.com/cgi-bin/user/info?access_token="+ Constant.getAccessToken() +"&openid="+openId+"&lang=zh_CN";
        try {
            JSONObject jsonObject = HttpClientUtil.doGet(url);
            wxUser = JsonUtil.fromJson(jsonObject.toString(), WxUser.class);

            System.out.println(wxUser.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return wxUser;
    }











}
