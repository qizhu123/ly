package com.example.wechat.common;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class CreateMenu {


/*
    public static String getAccessToken() {

        String url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=wx5ff0695459500f4e&secret=182852b10d4daff786c32483c727bf98";

        */

    /**
     * 发送get请求
     *//*


        HttpGet httpGet = new HttpGet(url);
        HttpClient httpClient = new DefaultHttpClient();
        try {
            HttpResponse httpResponse = httpClient.execute(httpGet);
            if (httpResponse.getStatusLine().getStatusCode() == 200) {
                String s = EntityUtils.toString(httpResponse.getEntity(), "utf-8");
                JSONObject jsonObject = new JSONObject(s);
                return jsonObject.get("access_token").toString();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


        return "";
    }

    public static void main(String[] args) {

        String accessToken = getAccessToken();
        if (accessToken != null) {
            String url = "https://api.weixin.qq.com/cgi-bin/menu/create?access_token=" + accessToken;
            HttpPost httpPost = new HttpPost(url);
            HttpClient httpClient = new DefaultHttpClient();

            JSONObject big = new JSONObject();
            JSONArray button = new JSONArray();

            JSONObject menu1 = new JSONObject();
            menu1.put("type","view");
            menu1.put("name","百度");
            menu1.put("url","https://www.baidu.com/");

            JSONObject menu2 = new JSONObject();
            menu2.put("type","view");
            menu2.put("name","hao123");
            menu2.put("url","https://www.hao123.com/");

            JSONObject menu3 = new JSONObject();
            menu3.put("type","view");
            menu3.put("name","新浪");
            menu3.put("url","https://www.sina.com.cn/");

            button.put(menu1);
            button.put(menu2);
            button.put(menu3);

            big.put("button",button);
            httpPost.setEntity(new StringEntity(big.toString(),"utf-8"));

            try {
                HttpResponse httpResponse = httpClient.execute(httpPost);

                if (httpResponse.getStatusLine().getStatusCode()==200){
                    String s = EntityUtils.toString(httpResponse.getEntity(), "utf-8");
                    System.out.println(s);
                }


            } catch (IOException e) {
                e.printStackTrace();
            }


        }

    }
*/


//    public static String getAccessToken() {
//
//        String access_token=null;
//        String url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=wx5ff0695459500f4e&secret=182852b10d4daff786c32483c727bf98";
//
//        try {
//            JSONObject jsonObject = HttpClientUtil.doGet(url);
//            access_token=jsonObject.get("access_token").toString();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//
//        return access_token;
//    }


    /**
     * 注意当main方方法里的菜单属性修改了后必须运行一下不然不更新改的东西
     * @param args
     */
    public static void main(String[] args) {

       // String accessToken = getAccessToken();

        String  accessToken=Constant.getAccessToken();

        if (accessToken != null) {
            String url = "https://api.weixin.qq.com/cgi-bin/menu/create?access_token=" + accessToken;


            JSONObject big = new JSONObject();
            JSONArray button = new JSONArray();

            JSONObject menu1 = new JSONObject();
            menu1.put("type", "view");
            menu1.put("name", "商城首页");
            menu1.put("url", ChangeUrlToOauthUrl.changeUrl("http://0gymwv8.hn3.mofasuidao.cn/app/index.html"));

            JSONObject menu2 = new JSONObject();
            menu2.put("type", "view");
            menu2.put("name", "个人中心");
            menu2.put("url", ChangeUrlToOauthUrl.changeUrl("http://0gymwv8.hn3.mofasuidao.cn/app/pcenter.html"));

            JSONObject menu3 = new JSONObject();
            menu3.put("type", "view");
            menu3.put("name", "购物车");
            menu3.put("url", ChangeUrlToOauthUrl.changeUrl("http://0gymwv8.hn3.mofasuidao.cn/app/shopcar.html"));

            button.put(menu1);
            button.put(menu2);
            button.put(menu3);

            big.put("button", button);

            try {
                JSONObject jsonObject = HttpClientUtil.doPost(url, big.toString());
                System.out.println(jsonObject);
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

    }




}
