package com.example.wechat.common;

import org.json.JSONObject;

import java.io.IOException;

public class Constant {

    //测试时用的，使用微信公众号测试二维码的时候用这个
    public static final String APPID = "wx5ff0695459500f4e";
    public static final String APPSECRET = "182852b10d4daff786c32483c727bf98";

    //正式的时支付时需要用到，所以支付时把上面的两个变为下面的的这两个（注意区分）
    //正式公众号APPID
    //public static final String APPID = "wxc37f01894579f97b";
    //正式公众号APPSECRET
   // public static final String APPSECRET = "3fbcaa5d45231815023070fdd2220a49";
    //正式公众号MCHID
    public static final String MCHID = "1519853611";
    //正式公众号KEY
    public static final String KEY = "1234567890qwertyuiopasdfghjklzxc";
    public static String ACCESS_TOKEN = null;//全局唯一调用凭证
    public static Long ACCESS_TOKEN_TIME = 0L;

    public static String JSAPI_TICKET = null;//用于调用微信JS接口的临时票据
    public static Long JSAPI_TICKET_TIME = 0L;

    public static String getAccessToken() {

        Long nowTime = System.currentTimeMillis() / 1000;
        System.out.println(nowTime);
        System.out.println(ACCESS_TOKEN_TIME);
        if (ACCESS_TOKEN == null || (nowTime - ACCESS_TOKEN_TIME) > 7000) {
            String url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" + APPID + "&secret=" + APPSECRET;
            try {
                JSONObject jsonObject = HttpClientUtil.doGet(url);
                if (jsonObject != null) {
                    ACCESS_TOKEN = (String) jsonObject.get("access_token");
                    ACCESS_TOKEN_TIME = System.currentTimeMillis() / 1000;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        return ACCESS_TOKEN;
    }



    public  static  String getJsapiTicket(){

        long nowTime = System.currentTimeMillis() / 1000;
        if(JSAPI_TICKET==null||(nowTime-JSAPI_TICKET_TIME)>7000){
            String accessToken = getAccessToken();
            String url="https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token="+accessToken+"&type=jsapi";
            try {
                JSONObject jsonObject = HttpClientUtil.doGet(url);
                JSAPI_TICKET = jsonObject.get("ticket").toString();

            } catch (IOException e) {
                e.printStackTrace();
            }

        }

        return JSAPI_TICKET;
    }




    public static void main(String[] args) {
        System.out.println(getJsapiTicket());
    }


}
