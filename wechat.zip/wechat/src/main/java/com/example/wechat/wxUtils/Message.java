package com.example.wechat.wxUtils;

public class Message {

//    public  void msgType(String msgType,String event){
//        //进入消息类型
//        if(msgType.equals("event")){
//            System.out.println("进入事件类型消息");
//            //进入事件类型
//            if (event.equals("subscribe")){
//                System.out.println("进入关注事件");
//            }else  if (event.equals("unsubscribe")){
//                System.out.println("进入取消关注事件");
//            }else  if (event.equals("SCAN")){
//                System.out.println("进入SCAN");
//            }else  if (event.equals("LOCATION")){
//                System.out.println("进入LOCATION");
//            }else  if (event.equals("CLICK")){
//                System.out.println("进入CLICK");
//            }else  if (event.equals("VIEW")){
//                System.out.println("进入VIEW");
//            }
//
//        }else  if(msgType.equals("text")){
//            System.out.println("进入文本消息");
//        }else  if(msgType.equals("image")){
//            System.out.println("进入图片消息");
//        }else  if(msgType.equals("voice")){
//            System.out.println("进入语音消息");
//        }else  if(msgType.equals("video")){
//            System.out.println("进入视频消息");
//        }else  if(msgType.equals("shortvideo")){
//            System.out.println("进入小视频消息");
//        }else  if(msgType.equals("location")){
//            System.out.println("进入地理位置消息");
//        }else  if(msgType.equals("link")){
//            System.out.println("进入链接消息");
//        }
//
//
//    }

}
