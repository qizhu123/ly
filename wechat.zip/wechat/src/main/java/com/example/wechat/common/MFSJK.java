package com.example.wechat.common;

import java.util.HashMap;
import java.util.Map;

public class MFSJK {

    //把它模仿成数据库来存取数据
    public   static Map<String,String> mapSJK= new HashMap<>();




}
