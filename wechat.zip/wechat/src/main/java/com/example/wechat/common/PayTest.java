package com.example.wechat.common;

import com.github.wxpay.sdk.WXPay;

import java.util.HashMap;
import java.util.Map;

public class PayTest {

    public static void main(String[] args) {
//        WXPay wxPay=new WXPay(new MyWXPayConfig());
//        Map<String,String> reqData=new HashMap<>();
//        reqData.put("body","扫码支付测试，LY");
//        reqData.put("out_trade_no","201911261213");
//        reqData.put("total_fee","1");
//        reqData.put("spbill_create_ip","123.12.12.123");
//        reqData.put("notify_url","http://0gymwv8.hn3.mofasuidao.cn/wechat/pay/notifyUrl");
//        reqData.put("trade_type","NATIVE");
//
//        try {
//            Map<String, String> requestData= wxPay.fillRequestData(reqData);
//            Map<String, String> unifiedOrder = wxPay.unifiedOrder(requestData);
//            System.out.println(unifiedOrder.toString());
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//

    }

}





























