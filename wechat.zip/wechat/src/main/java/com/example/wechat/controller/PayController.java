package com.example.wechat.controller;

import com.example.wechat.common.DateUtil;
import com.example.wechat.common.JsonBean;
import com.example.wechat.common.MFSJK;
import com.example.wechat.common.MyWXPayConfig;
import com.github.wxpay.sdk.WXPay;
import com.github.wxpay.sdk.WXPayUtil;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("pay")
public class PayController {

    //假装是个数据库
    Map<String, String> mapSJK = MFSJK.mapSJK;

    @PostMapping("checkOrder")
    public JsonBean checkOrder(String out_trade_no){
        JsonBean jsonBean = new JsonBean(-1, "失败", null);
        System.out.println("支付状态："+mapSJK.get("payStatus"));
        if(mapSJK.get("payStatus").equals("1")){

            jsonBean = new JsonBean(0, "成功", null);
        }

        return  jsonBean;
    }





    @PostMapping("nativePay")
    public JsonBean nativePay(){

        /**
         * 当前业务应该在业务里完成
         */
        //价格
        JsonBean jsonBean = new JsonBean(-1, "失败", null);
        String total_fee="1";//由数据库通过前端传会来的商品id查出价格，不能由前端直接传回商品价格（因为前端价格可能回被改动，不是很可靠，凡是和钱相关的应该从数据库中获得）
        String sdfTimes = DateUtil.getSdfTimes();
        //订单编号的生成规则：DD-顾客id-商品id+当前日期，中间加-方便通过订单编号取编号里面的信息如商品id等
        String out_trade_no ="DD-32-1-"+sdfTimes;

        WXPay wxPay=new WXPay(new MyWXPayConfig());
        Map<String,String> reqData=new HashMap<>();
        reqData.put("body","此处应该是要购买商品的信息yo!!");
        reqData.put("out_trade_no",out_trade_no);
        reqData.put("total_fee",total_fee);
        reqData.put("spbill_create_ip","123.12.12.123");
        reqData.put("notify_url","http://0gymwv8.hn3.mofasuidao.cn/wechat/pay/notifyUrl");
        reqData.put("trade_type","NATIVE");

        try {
            Map<String, String> requestData= wxPay.fillRequestData(reqData);
            Map<String, String> unifiedOrder = wxPay.unifiedOrder(requestData);
            System.out.println(unifiedOrder.toString());

            //如果这两个都为success则表明生成预支付交易单成功而且能返回code_url，这时我们可以把相关数据存入数据库，并且把前端所需要的数据响应给前端
            if(unifiedOrder.get("return_code").equals("SUCCESS")&&unifiedOrder.get("result_code").equals("SUCCESS")){

                mapSJK.put("out_trade_no",out_trade_no);
                mapSJK.put("code_url",unifiedOrder.get("code_url"));
                mapSJK.put("payStatus","-1");//先向数据库添加状态-1（表示未支付），等支付成功后微信回调返回return_code 为SUCCESS时表示成功，就可以通过订单编号out_trade_no去把数据库中的状态改为1（支付成功状态）

                jsonBean = new JsonBean(0, "成功", mapSJK);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }



        return jsonBean;
    }




    @GetMapping("notifyUrl")
    public String notifyUrl(HttpServletRequest request){

        String xml="";
        System.out.println("接收到了微信的回调");

        ServletInputStream inputStream= null;
        try {
            inputStream = request.getInputStream();
            Element rootElement = new SAXBuilder().build(inputStream).getRootElement();//通过jodom解析方式，解析请求中的xml文件，获取xml文件信息
            String return_code = rootElement.getChildText("return_code");

            //如果微信xml返回的return_code的值为SUCCESS则表明支付成功，把支付状态改为1
            System.out.println("return_code为："+return_code);
            if(return_code.equals("SUCCESS")){
                System.out.println("支付成功");
                mapSJK.put("payStatus","1");

            }


        } catch (IOException e) {
            e.printStackTrace();
        } catch (JDOMException e) {
            e.printStackTrace();
        }


        //把这两个参数以微信想要的xml的形式返回给微信服务器，微信服务器就不会不断的回调本函数了，当用户支付成功后微信回访问notify_url（写的是这个函数的地址），回向请求中给个xml文件其中return_code为SUCCESS以表明客户支付成功，我们可以修改支付状态了，我们返回给微信一个下面形式的xml后微信就不会一直请求了
        Map<String,String> map=new HashMap<>();
        map.put("return_code","SUCCESS");
        map.put("return_msg","OK");

        try {
            xml = WXPayUtil.mapToXml(map);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return xml;
    }



}
