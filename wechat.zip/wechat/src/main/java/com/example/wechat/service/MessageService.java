package com.example.wechat.service;

import org.jdom2.Element;

public interface MessageService {
    public  String updateMessage( Element rootElement);
}
