package com.example.wechat.controller;

import com.example.wechat.common.*;
import com.example.wechat.domain.model.WxUser;
import com.example.wechat.service.MessageService;
import com.example.wechat.service.WxUserService;
import com.example.wechat.vo.WeChatVo;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Map;

@RestController
public class WeChatController {

    @Autowired
    private MessageService messageService;

    @Autowired
    private WxUserService wxUserService;

    @GetMapping("index")
    public String getIndexInfo(WeChatVo weChatVo) {
        if (weChatVo.getEchostr() != null) {

            if (weChatVo.getSignature().equals(weChatVo.getSha1())) {
                System.out.println(weChatVo.getSignature());
                System.out.print("成功匹配到微信");
                return weChatVo.getEchostr();
            }

        }

        return "ly";
    }


    @PostMapping("index")
    public String postIndex(HttpServletRequest request){//当用户和微信公众号发生交互时微信服务器会向开发者（我们）发送一个带xml文件的请求，包含五个重要参数

        String xml="Success";

        try {
            ServletInputStream inputStream=request.getInputStream();
            Element rootElement = new SAXBuilder().build(inputStream).getRootElement();//通过jodom解析方式，解析请求中的xml文件，获取xml文件信息

            xml=messageService.updateMessage(rootElement);

        } catch (IOException e) {
            e.printStackTrace();
        } catch (JDOMException e) {
            e.printStackTrace();
        }

        //完成后进行图文推送,通过响应返回给微信服务器一个xml文件（里面包含有我们给微信用户推送的图文消息）
        return xml;
    }



    @PostMapping("oauth")
    public JsonBean oauth(String code,HttpServletRequest request){

        System.out.println("code====>"+code);

        String url="https://api.weixin.qq.com/sns/oauth2/access_token?appid="+Constant.APPID+"&secret="+Constant.APPSECRET+"&code="+code+"&grant_type=authorization_code";
        String openid="";
        try {
            JSONObject jsonObject = HttpClientUtil.doGet(url);
            openid=jsonObject.get("openid").toString();
            System.out.println("jsonObject--->"+jsonObject);
            WxUser wxUser = wxUserService.selectByOpenId(openid);
            if(wxUser!=null){
                System.out.println("用户存在"+wxUser.toString());
                request.getSession().setAttribute("wxUser",wxUser);
            }


        } catch (IOException e) {
            e.printStackTrace();
        }


        return new JsonBean(0,"ok",openid);
    }


    //把以前的jssdk变为很多网页都需要分享的share
    @PostMapping("share")
    public JsonBean share(String targetUrl,HttpServletRequest request){

        System.out.println("url======》"+targetUrl);

        WxUser wxUser = (WxUser) request.getSession().getAttribute("wxUser");
        System.out.println(wxUser);

        String url="https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token="+Constant.getAccessToken();
        //当action_name为QR_STR_SCENE（有STR说明为字符串参数值），后面的场景值ID为字符串类型写成scene_str；如果前面action_name没有STR字母则表明它是整数型的后面则用scene_id
        String string="{\"expire_seconds\": 2592000, \"action_name\": \"QR_STR_SCENE\", \"action_info\": {\"scene\": {\"scene_str\": "+wxUser.getId()+"}}}";//这里通过当前用户的id来设置场景值ID，而不是把它写死
        String ticket=null;
        try {
            JSONObject jsonObject = HttpClientUtil.doPost(url, string);
            System.out.println("jsonObject"+jsonObject);
            ticket=jsonObject.get("ticket").toString();
            System.out.println(ticket);

            //通过ticket换取二维码, HTTP GET请求（请使用https协议）"https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket="+ticket，通过这个网址我们可以获取二维码图片

        } catch (IOException e) {
            e.printStackTrace();
        }



        Map<String, Object> map = JsSdkUtil.getJsSdkConfigMap(targetUrl);
        //把ticket也放到map集合里，传会给前端
        map.put("ticket",ticket);
        System.out.println("map=====》"+map);
        return new JsonBean(0,"ok",map);
    }




    @GetMapping("wxFS")
    public JsonBean wxFS(HttpServletRequest request){
        WxUser wxUser = (WxUser) request.getSession().getAttribute("wxUser");
        JsonBean jsonBean = wxUserService.selectByfId(wxUser.getId().toString());


        return  jsonBean;
    }



}
